const csvForm = document.getElementById("csvForm");
const csvFile = document.getElementById("csvFile");
let defaultRoadProperties;
let defaultJunctionProperties;
let defaultRoadRelativeWeighting;
let defaultJunctionRelativeWeighting;
let customRoadProperties;
let customJunctionProperties;
let customRoadRelativeWeighting;
let customJunctionRelativeWeighting;
let defaultRoad;
let defaultJunction;
let roadOrJunction;




csvForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const input = decisionMapCSVFile.files[0];
    const csvReader = new FileReader();

    csvReader.onload = function (e) {
        const text = e.target.result;
        const decisionMapArray = convertCSVToArray(text);

        if (localStorage.getItem("csvFile") == null) {
            localStorage.setItem("decisionMap", decisionMapArray);
            console.log(localStorage.getItem("decisionMap"));
        }
    };
    csvReader.readAsText(input);
});



function showMe(elem) {
    const elements = document.getElementsByClassName('switchable');

    for (const element of elements) {
        element.style.display = 'none';
    }
    document.getElementById(elem).style.display = 'block';
};
const q = JSON.parse(localStorage.defaultRoadProperties);
function dijkstra() {
    const problem = {
        start: {
            1: q[0][0][0][1],
            2: 2
        },
        1: {
            9: 4
        },
        2: {
            3: 8
        },
        3: {
            4: 6,
            7: 3
        },
        4: {
            5: 1
        },
        5: {
            6: 2
        },
        6: {
            10: 2
        },
        7: {
            8: 4
        },
        8: {
            10: 1
        },
        9: {
            7: 3,
            13: 2,
            12: 7
        },
        10: {
            21: 2,
            11: 4
        },
        11: {
            15: 2
        },
        12: {
            13: 4,
            16: 2
        },
        13: {
            14: 3
        },
        14: {
            18: 3,
            24: 5
        },
        15: {
            19: 5,
            17: 2
        },
        16: {
            22: 5
        },
        17: {
            21: 4
        },
        18: {
            20: 3,
            28: 1
        },
        19: {
            21: 4
        },
        20: {
            21: 3
        },
        21: {
            36: 7
        },
        22: {
            26: 1
        },
        23: {
            25: 3,
            29: 7
        },
        24: {
            27: 6,
            31: 1
        },
        25: {
            27: 1,
            31: 6
        },
        26: {
            23: 2,
            34: 7
        },
        27: {
            33: 1
        },
        28: {
            39: 8,
            35: 2
        },
        29: {
            31: 4
        },
        30: {
            31: 8
        },
        31: {
            32: 2
        },
        32: {
            40: 8
        },
        33: {
            32: 5
        },
        34: {
            30: 9,
            38: 1
        },
        35: {
            37: 1
        },
        36: {
            45: 1
        },
        37: {
            45: 7
        },
        38: {
            41: 8
        },
        39: {
            35: 4
        },
        40: {
            42: 1
        },
        41: {
            59: 6
        },
        42: {
            60: 9
        },
        43: {
            55: 3,
            42: 1
        },
        44: {
            43: 7
        },
        45: {
            44: 3
        },
        46: {
            47: 1,
            48: 5
        },
        47: {
            49: 1
        },
        48: {
            49: 2
        },
        49: {
            50: 3
        },
        50: {
            51: 6
        },
        51: {
            58: 2,
            52: 3
        },
        52: {
            57: 8
        },
        53: {
            54: 8
        },
        54: {
            55: 2,
            52: 3
        },
        55: {
            56: 3
        },
        56: {
            finish: 1
        },
        57: {
            finish: 2
        },
        58: {
            59: 7
        },
        59: {
            finish: 3
        },
        finish: {}
    };

    console.log(problem);

    const lowestCostNode = (costs, processed) => {
        return Object.keys(costs).reduce((lowest, node) => {
            if (lowest === null || costs[node] < costs[lowest]) {
                if (!processed.includes(node)) {
                    lowest = node;
                }
            }
            return lowest;
        }, null);
    };

    // function that returns the minimum cost and path to reach Finish
    const computeShortestPath = (graph) => {

        // track lowest cost to reach each node
        const costs = Object.assign({
            finish: Infinity
        }, graph.start);

        // track paths
        const parents = {
            finish: null
        };
        for (let child in graph.start) {
            parents[child] = 'start';
        }

        // track nodes that have already been processed
        const processed = [];

        let node = lowestCostNode(costs, processed);

        while (node) {
            let cost = costs[node];
            let children = graph[node];
            for (let n in children) {
                let newCost = cost + children[n];
                if (!costs[n]) {
                    costs[n] = newCost;
                    parents[n] = node;
                }
                if (costs[n] > newCost) {
                    costs[n] = newCost;
                    parents[n] = node;
                }
            }
            processed.push(node);
            node = lowestCostNode(costs, processed);
        }

        let optimalPath = ['finish'];
        let parent = parents.finish;
        while (parent) {
            optimalPath.push(parent);
            parent = parents[parent];
        }
        optimalPath.reverse();

        const results = {
            distance: costs.finish,
            path: optimalPath
        };

        return results;
    };

    return computeShortestPath(problem);
};


pageInit();

function pageInit() {
    // Display initial elements on page load

    showMe('startScreen');

    defaultOrCustom();

    if (localStorage.defaultRoadProperties == null &&
        localStorage.defaultJunctionProperties == null &&
        localStorage.defaultRoadRelativeWeighting == null &&
        localStorage.defaultJunctionRelativeWeighting == null &&
        localStorage.customRoadProperties == null &&
        localStorage.customJunctionProperties == null &&
        localStorage.customRoadRelativeWeighting == null &&
        localStorage.customJunctionRelativeWeighting == null) {
        populateDefaultRoadProperties();
        localStorage.defaultRoadProperties = JSON.stringify(defaultRoadProperties);
        localStorage.defaultRoadRelativeWeighting = JSON.stringify(defaultRoadRelativeWeighting);
        populateDefaultJunctionProperties();
        localStorage.defaultJunctionProperties = JSON.stringify(defaultJunctionProperties);
        localStorage.defaultJunctionRelativeWeighting = JSON.stringify(defaultJunctionRelativeWeighting);


        document.getElementById("labelDefaultExistingCustomise").innerHTML = "Default weightings for roads and junctions have been loaded";
        document.getElementById("btnUseDefaultRoadJunctionValues").style.display = "inline-block";
        document.getElementById("btnUseExistingRoadJunctionValues").style.display = "none";
        document.getElementById("btnSetDefaultRoadJunctionValues").style.display = "none";
    } else if ((localStorage.customRoadProperties != localStorage.defaultRoadProperties ||
        localStorage.customJunctionProperties != localStorage.defaultJunctionProperties ||
        localStorage.customRoadRelativeWeighting != defaultRoadRelativeWeighting ||
        localStorage.customJunctionRelativeWeighting != defaultJunctionRelativeWeighting) &&
        (localStorage.customRoadProperties != null ||
            localStorage.customJunctionProperties != null ||
            localStorage.customRoadRelativeWeighting != null ||
            localStorage.customJunctionRelativeWeighting != null)) {


        document.getElementById("labelDefaultExistingCustomise").innerHTML = "Previously customised weightings for roads and junctions have been loaded";
        document.getElementById("btnSetDefaultRoadJunctionValues").style.display = "inline-block";
        document.getElementById("btnUseDefaultRoadJunctionValues").style.display = "none";
        document.getElementById("btnUseExistingRoadJunctionValues").style.display = "inline-block";

    } else {
        document.getElementById("labelDefaultExistingCustomise").innerHTML = "Default weightings for roads and junctions were previously loaded";
        document.getElementById("btnSetDefaultRoadJunctionValues").style.display = "none";
        document.getElementById("btnUseDefaultRoadJunctionValues").style.display = "none";
        document.getElementById("btnUseExistingRoadJunctionValues").style.display = "none";
    };

    if (localStorage.defaultJunctionRelativeWeighting == null) {
        console.log("hi");
    };


    // Execute the algorithm with the current values
    console.log(dijkstra());





    {
        // Hook up the "Calculate with current values" button
        var btnUseExistingRoadJunctionValues = document.getElementById('btnUseExistingRoadJunctionValues');
        if (btnUseExistingRoadJunctionValues.addEventListener) {
            // DOM2 standard
            btnUseExistingRoadJunctionValues.addEventListener('click', function () {
                showMe('resultScreen')
            });
        } else if (btnUseExistingRoadJunctionValues.attachEvent) {
            // IE (IE9 finally supports the above, though)
            btnUseExistingRoadJunctionValues.attachEvent('onclick', showMe('resultScreen'));
        } else {
            // Really old or non-standard browser, try DOM0
            btnUseExistingRoadJunctionValues.onclick = showMe('resultScreen');
        };


        // Hook up the "Customise values" button
        var btnCustomiseRoadJunctionValues = document.getElementById('btnCustomiseRoadJunctionValues');
        if (btnCustomiseRoadJunctionValues.addEventListener) {
            // DOM2 standard
            btnCustomiseRoadJunctionValues.addEventListener('click', function () {
                showMe('customPage1')
            });
        } else if (btnCustomiseRoadJunctionValues.attachEvent) {
            // IE (IE9 finally supports the above, though)
            btnCustomiseRoadJunctionValues.attachEvent('onclick', showMe('customPage1'));
        } else {
            // Really old or non-standard browser, try DOM0
            btnCustomiseRoadJunctionValues.onclick = showMe('customPage1');
        };


        // Hook up the "Scenario 1" button
        var btnShowS1 = document.getElementById('btnShowS1');
        if (btnShowS1.addEventListener) {
            // DOM2 standard
            btnShowS1.addEventListener('click', function () {
                showMe('customPage1')
            });
        } else if (btnShowS1.attachEvent) {
            // IE (IE9 finally supports the above, though)
            btnShowS1.attachEvent('onclick', showMe('customPage1'));
        } else {
            // Really old or non-standard browser, try DOM0
            btnShowS1.onclick = showMe('customPage1');
        };


        // Hook up the "Scenario 2" button
        var btnShowS2 = document.getElementById('btnShowS2');
        if (btnShowS2.addEventListener) {
            // DOM2 standard
            btnShowS2.addEventListener('click', function () {
                showMe('customPage2')
            });
        } else if (btnShowS2.attachEvent) {
            // IE (IE9 finally supports the above, though)
            btnShowS2.attachEvent('onclick', showMe('customPage2'));
        } else {
            // Really old or non-standard browser, try DOM0
            btnShowS2.onclick = showMe('customPage2');
        };


        // Hook up the "Scenario 3" button
        var btnShowS3 = document.getElementById('btnShowS3');
        if (btnShowS3.addEventListener) {
            // DOM2 standard
            btnShowS3.addEventListener('click', function () {
                showMe('customPage3')
            });
        } else if (btnShowS3.attachEvent) {
            // IE (IE9 finally supports the above, though)
            btnShowS3.attachEvent('onclick', showMe('customPage3'));
        } else {
            // Really old or non-standard browser, try DOM0
            btnShowS3.onclick = showMe('customPage3');
        };


        // Hook up the "Scenario 4" button
        var btnShowS4 = document.getElementById('btnShowS4');
        if (btnShowS4.addEventListener) {
            // DOM2 standard
            btnShowS4.addEventListener('click', function () {
                showMe('customPage4')
            });
        } else if (btnShowS4.attachEvent) {
            // IE (IE9 finally supports the above, though)
            btnShowS4.attachEvent('onclick', showMe('customPage4'));
        } else {
            // Really old or non-standard browser, try DOM0
            btnShowS4.onclick = showMe('customPage4');
        };


        // Hook up the "Scenario 5" button
        var btnShowS5 = document.getElementById('btnShowS5');
        if (btnShowS5.addEventListener) {
            // DOM2 standard
            btnShowS5.addEventListener('click', function () {
                showMe('customPage5')
            });
        } else if (btnShowS5.attachEvent) {
            // IE (IE9 finally supports the above, though)
            btnShowS5.attachEvent('onclick', showMe('customPage5'));
        } else {
            // Really old or non-standard browser, try DOM0
            btnShowS5.onclick = showMe('customPage5');
        };

        // Hook up the "Scenario 6" button
        var btnShowS6 = document.getElementById('btnShowS6');
        if (btnShowS6.addEventListener) {
            // DOM2 standard
            btnShowS6.addEventListener('click', function () {
                showMe('customPage6')
            });
        } else if (btnShowS6.attachEvent) {
            // IE (IE9 finally supports the above, though)
            btnShowS6.attachEvent('onclick', showMe('customPage6'));
        } else {
            // Really old or non-standard browser, try DOM0
            btnShowS6.onclick = showMe('customPage6');
        };

        // Hook up the "Scenario 7" button
        var btnShowS7 = document.getElementById('btnShowS7');
        if (btnShowS7.addEventListener) {
            // DOM2 standard
            btnShowS7.addEventListener('click', function () {
                showMe('customPage7')
            });
        } else if (btnShowS7.attachEvent) {
            // IE (IE9 finally supports the above, though)
            btnShowS7.attachEvent('onclick', showMe('customPage7'));
        } else {
            // Really old or non-standard browser, try DOM0
            btnShowS7.onclick = showMe('customPage7');
        };

        // Hook up the "Scenario 8" button
        var btnShowS8 = document.getElementById('btnShowS8');
        if (btnShowS8.addEventListener) {
            // DOM2 standard
            btnShowS8.addEventListener('click', function () {
                showMe('customPage8')
            });
        } else if (btnShowS8.attachEvent) {
            // IE (IE9 finally supports the above, though)
            btnShowS8.attachEvent('onclick', showMe('customPage8'));
        } else {
            // Really old or non-standard browser, try DOM0
            btnShowS8.onclick = showMe('customPage8');
        };

        // Hook up the "Scenario 9" button
        var btnShowS9 = document.getElementById('btnShowS9');
        if (btnShowS9.addEventListener) {
            // DOM2 standard
            btnShowS9.addEventListener('click', function () {
                showMe('customPage9')
            });
        } else if (btnShowS9.attachEvent) {
            // IE (IE9 finally supports the above, though)
            btnShowS9.attachEvent('onclick', showMe('customPage9'));
        } else {
            // Really old or non-standard browser, try DOM0
            btnShowS9.onclick = showMe('customPage9');
        }
    };
};

function convertCSVToArray(str, delim = ",") {
    // Start from the start of the string, slice at end of line marker
    // Use the delimeter set above to split the string
    const headers = str.slice(0, str.indexOf("\n")).split(delim);

    // Start at the index \n + 1 and slice at the end of the text
    // Create an array of each csv row, using Split
    const rows = str.slice(str.indexOf("\n") + 1).split("\n");

    // Maping the rows
    // Split the values from each row into an array
    // Create an object using headers.reduce
    // Derive the object properties from headers:values
    // Construct the array using the object as an element of the whole array
    const array = rows.map(function (row) {
        const values = row.split(delim);
        const element = headers.reduce(function (object, header, index) {
            object[header] = values[index];
            return object;
        }, {});
        return element;
    });

    // return the array
    return array;
};

function populateDefaultRoadProperties() {

    const speedLimit = [
        ['AA', 5, "10mph"],
        ['AB', 4, "20mph"],
        ['AC', 3, "30mph"],
        ['AD', 0, "40mph"],
        ['AE', -2, "50mph"],
        ['AF', -4, "60mph"],
        ['AG', -5, "70mph"]
    ];

    const noOfLanes = [
        ['BA', 5, "1 Lane"],
        ['BB', 3, "2 Lanes"],
        ['BC', 1, "3 Lanes"],
        ['BD', -1, "4 Lanes"],
        ['BE', -3, "5 Lanes"],
        ['BF', -5, "6 Lanes"],
    ];

    const trafficFlow = [
        ['CA', 0, "One way"],
        ['CB', -2, "Two way"]
    ];

    const bikeLane = [
        ['GA', 3, "Continuous, clearly marked"],
        ['GB', -4, "Interrupted"],
        ['GC', -2, "Hard to follow"],
        ['GD', 0, "No bike lane"]
    ];

    const busLane = [
        ['HA', 4, "Continuous, clearly marked"],
        ['HB', -3, "Interrupted"],
        ['HC', -1, "Hard to follow"],
        ['HD', 0, "No bus lane"]
    ];

    const trafficCalmingMeasure = [
        ['IA', 0, "None"],
        ['IB', 0, "Traffic Lights"],
        ['IC', 3, "Bicycle Priority Traffic Lights"],
        ['ID', -1, "Speed Bumps"],
        ['IE', -2, "Width Restriction Islands"],
        ['IF', -3, "Narrowing Islands"],
        ['IG', 2, "Speed Camera"]
    ];

    const noOfAdjacentRoadsCrossed = [
        ['JA', 5, "0"],
        ['JB', 4, "1"],
        ['JC', 3, "2"],
        ['JD', 2, "3"],
        ['JE', 1, "4"],
        ['JF', -1, "5"],
        ['JG', -2, "6"],
        ['JH', -3, "7"],
        ['JI', -4, "8"],
        ['JJ', -5, "9"]
    ];

    const rateOfTraffic = [
        ['KA', 0, "Low"],
        ['KB', -2, "Medium"],
        ['KC', -5, "High"]
    ];

    defaultRoadProperties = [
        [speedLimit],
        [noOfLanes],
        [trafficFlow],
        [bikeLane],
        [busLane],
        [trafficCalmingMeasure],
        [noOfAdjacentRoadsCrossed],
        [rateOfTraffic]
    ];

    defaultRoadRelativeWeighting = [5, 4, 2, 5, 4, 2, 1, 4];

    return defaultRoadProperties, defaultRoadRelativeWeighting;
};

function populateDefaultJunctionProperties() {

    const junctionType = [
        ['AA', 2, "Mini Roundabout"],
        ['AB', 4, "Roundabout"],
        ['AC', 0, "T Junction"],
        ['AD', -2, "Crossroads"],
        ['AE', -1, "Slip Road"]
    ];

    const noOfLanes = [
        ['BA', 5, "1 Lane"],
        ['BB', 3, "2 Lanes"],
        ['BC', 1, "3 Lanes"],
        ['BD', -1, "4 Lanes"],
        ['BE', -3, "5 Lanes"],
        ['BF', -5, "6 Lanes"]
    ];

    const trafficFlow = [
        ['CA', 0, "One way"],
        ['CB', -2, "Two way"]
    ];

    const turningDirection = [
        ['DA', 0, "Left"],
        ['DB', -4, "Right"],
        ['DC', -5, "Straight"]
    ];

    const rightOfWay = [
        ['FA', 0, "Yes"],
        ['FB', -4, "No"]
    ];

    const bikeLane = [
        ['GA', 3, "High Quality"],
        ['GB', -3, "Interrupted"],
        ['GC', -4, "Hard to follow"],
        ['GD', 0, "No bike lane"]
    ];

    const busLane = [
        ['HA', 4, "High Quality"],
        ['HB', -1, "Interrupted"],
        ['HC', -3, "Hard to follow"],
        ['HD', 0, "No bus lane"]
    ];

    const trafficLights = [
        ['IA', 0, "No"],
        ['IB', 3, "Yes"],
        ['IC', 5, "Bicycle Priority"]
    ];

    const directionsOfTraffic = [
        ['JA', 5, "1"],
        ['JB', 4, "2"],
        ['JC', 3, "3"],
        ['JD', 2, "4"],
        ['JE', 0, "5"],
        ['JF', -1, "6"],
        ['JG', -2, "7"],
        ['JH', -4, "8"],
        ['JI', -5, "9"]
    ];

    const rateOfTraffic = [
        ['KA', 0, "Low"],
        ['KB', -2, "Medium"],
        ['KC', -5, "High"]
    ];

    defaultJunctionProperties = [
        [junctionType],
        [noOfLanes],
        [trafficFlow],
        [turningDirection],
        [rightOfWay],
        [bikeLane],
        [busLane],
        [trafficLights],
        [directionsOfTraffic],
        [rateOfTraffic]
    ];

    defaultJunctionRelativeWeighting = [2, 3, 4, 4, 1, 2, 3, 4, 5, 3, 5];

    return defaultJunctionProperties, defaultJunctionRelativeWeighting;
};

function getValue(roadOrJunction, one, two, three, four) {
    defaultOrCustom();
    if (roadOrJunction) {
        if (defaultRoad) {
            document.querySelector('#s1Q1Slider').innerHTML = localStorage.defaultRoadProperties[one][two][three][four];
            document.querySelector('#s1Q1Label').innerHTML = localStorage.defaultRoadProperties[one][two][three][four];
            document.querySelector('#s1Q1Slider').value = localStorage.defaultRoadProperties[one][two][three][four];
            document.querySelector('#s1Q1Label').value = localStorage.defaultRoadProperties[one][two][three][four];
            
        } else {
            document.querySelector('#s1Q1Slider').innerHTML  = localStorage.customRoadProperties[one][two][three][four];
            document.querySelector('#s1Q1Label').innerHTML = localStorage.customRoadProperties[one][two][three][four];
            document.querySelector('#s1Q1Slider').innerHTML  = localStorage.customRoadProperties[one][two][three][four];
            document.querySelector('#s1Q1Label').innerHTML = localStorage.customRoadProperties[one][two][three][four];
            
        };
    } else {
        console.log("dufhsdiufhsd");
        if (defaultRoad) {
            this.value = localStorage.defaultJunctionProperties[one][two][three][four];
        } else {
            this.value = localStorage.customJunctionProperties[one][two][three][four];
        };
    };

};

function resetSliderToDefaultValue(labelID, sliderID, roadOrJunction, one, two, three, four) {
    var value = JSON.parse(localStorage.defaultRoadProperties)[one][two][three][four];

    document.getElementById(labelID).innerHTML = value;
    document.getElementById(sliderID).value = value;

    customiseWeightings(roadOrJunction, one, two, three, four, document.getElementById(sliderID).value);
};

function customiseWeightings(roadOrJunction, one, two, three, four, newValue) {

    if (roadOrJunction) {
        defaultOrCustom();
        if (defaultRoad) {
            var customisingRoadProperties = JSON.parse(localStorage.defaultRoadProperties);
        } else {
            var customisingRoadProperties = JSON.parse(localStorage.customRoadProperties);
        };

        customisingRoadProperties[one][two][three][four] = newValue;

        localStorage.customRoadProperties = JSON.stringify(customisingRoadProperties);

    } else {
        if (defaultJunction) {
            var customisingJunctionProperties = JSON.parse(localStorage.defaultJunctionProperties);
        } else {
            var customisingJunctionProperties = JSON.parse(localStorage.customJunctionProperties);
        };

        customisingJunctionProperties[one][two][three][four] = newValue;

        localStorage.customJunctionProperties = JSON.stringify(customisingJunctionProperties);
    };
};

function defaultOrCustom() {
    if (localStorage.customRoadProperties == null) {
        defaultRoad = true;
    } else {
        defaultRoad = false;
    };
    if (localStorage.customRoadProperties == null) {
        defaultJunction = true;
    } else {
        defaultJunction = false;
    };
};